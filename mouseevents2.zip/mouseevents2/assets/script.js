$(document).ready(function(){
    
    var scrollPos;
    var xPos;
    var yPos;
    var winWidth;
    var winHeight;

    $(window).scroll(function(){ 
        scrollPos = $('body').scrollTop();
        $('#scroll-pos').html("scroll: " + scrollPos);
    });


    $(document).mousemove(function(e){
        xPos = e.pageX;
        yPos = e.pageY;
        $('#mouse-pos').html('x-pos: ' + xPos + '<br />y-pos: ' + yPos);

        $('#element').css({
            'transform' : 'rotate(' + xPos + 'deg) scale(' + xPos/100 + ')',
            'background-color' : 'rgb('+ yPos/5 + ', ' + xPos/3 + ', ' + (xPos*yPos)    /10 + ')',
        });

    });

    $(window).resize(function() {
        winWidth = $(window).width();
        winHeight = $(window).height();
        $('#window-size').html('window width: ' + winWidth + '<br />window height: ' + winHeight);
    });


});